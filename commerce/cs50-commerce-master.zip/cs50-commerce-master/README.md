# CS50 Web Programming

# Commerce
This website integrates the uses of Django with a database point of view with the ability to create and account, log in and either bid on active listings like you would
for ebay but as well as create your own listings of items to sell.
